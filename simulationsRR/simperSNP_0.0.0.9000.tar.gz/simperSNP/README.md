# simperSNP

This package simulates SNP data sets for simple and complex pedigrees. Founder individuals are assigned haplotypes based on founder allele frequencies. Haplotypes are then transmitted to descendants with recombination sampled from linkage map distances. Crossover positions are reported alongside datasets. 

This package is still in progress and is not currently functional.

Future versions will account for additional factors such as crossover intereference.
