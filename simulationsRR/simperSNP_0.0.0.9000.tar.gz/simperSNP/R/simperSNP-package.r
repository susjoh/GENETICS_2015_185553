#' simperSNP.
#' @title Simulates SNP Datasets For Simple And Complex Pedigrees With Recombination.
#' @name simperSNP
#' @docType package
#' @keywords package
#' @aliases simperSNP simperSNP-package
NULL
